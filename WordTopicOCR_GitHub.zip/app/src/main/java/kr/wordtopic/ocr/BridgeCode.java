package kr.wordtopic.ocr;
final class BridgeCode {
    static String make(String token) {
        return """
-- 주제 읽기 OCR: Hub를 먼저 실행한 뒤 이 코드를 실행하세요.
local env=type(getgenv)=='function' and getgenv() or _G
if env.WordTopicOCRBridge then env.WordTopicOCRBridge.active=false end
local session={active=true}
env.WordTopicOCRBridge=session
local requestFn=(syn and syn.request) or (http and http.request) or http_request or request
if type(requestFn)~='function' then
    session.active=false
    warn('이 실행기에서 HTTP 요청 함수를 찾지 못했습니다. OCR 연결 불가')
    return
end
local json=game:GetService('HttpService')
task.spawn(function()
    while session.active do
        local ok,value=pcall(function()
            local response=requestFn({Url='http://127.0.0.1:17653/topic?token=TOKEN_VALUE',Method='GET'})
            if response.StatusCode~=200 then return nil end
            local body=json:JSONDecode(response.Body)
            if body.running and type(body.topic)=='string' and body.topic~='' and tonumber(body.ageMs) and body.ageMs<1800 then
                return body.topic
            end
        end)
        if not session.active then break end
        if ok and value then
            session.message='휴대폰 OCR 연결됨'
            env.WordStackOCR={topic=value,receivedAt=os.clock()}
        else
            session.message=ok and '앱에서 주제 인식 대기' or '앱 연결 확인 필요 · 로컬 HTTP 요청 실패'
            env.WordStackOCR=nil
        end
        task.wait(0.45)
    end
end)
print('OCR 연결 시작: 앱에서 인식한 주제가 있어야 전달됩니다. 중지: getgenv().WordTopicOCRBridge.active=false')
""".replace("TOKEN_VALUE",token);
    }
}
