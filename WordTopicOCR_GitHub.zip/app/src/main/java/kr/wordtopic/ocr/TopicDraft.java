package kr.wordtopic.ocr;
import android.os.SystemClock;
/** A short-lived, process-local snapshot survives screen resize caused by the IME. */
final class TopicDraft {
    private static String topic="";
    private static long receivedAt=0;
    static synchronized void remember(String value){
        if(value!=null && !value.isEmpty()){topic=value;receivedAt=SystemClock.elapsedRealtime();}
    }
    static synchronized String fresh(){return SystemClock.elapsedRealtime()-receivedAt<30000?topic:"";}
}
