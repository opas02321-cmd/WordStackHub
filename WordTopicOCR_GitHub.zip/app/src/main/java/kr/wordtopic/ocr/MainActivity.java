package kr.wordtopic.ocr;

import android.app.*;
import android.content.*;
import android.media.projection.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.graphics.Color;
import android.widget.*;
import android.view.*;

public class MainActivity extends Activity {
    TextView state;
    boolean notificationAsked=false;
    final Handler handler = new Handler();
    final Runnable refresh = new Runnable() { public void run() {
        if(state!=null) state.setText(CaptureService.running ? "실행 중 · " + CaptureService.message + "\n인식한 주제: " + CaptureService.topic : "중지됨 · "+CaptureService.message);
        handler.postDelayed(this,700);
    }};
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(15,118,110));
        LinearLayout column=new LinearLayout(this); column.setOrientation(LinearLayout.VERTICAL); column.setPadding(28,40,28,24); column.setBackgroundColor(Color.rgb(243,248,247));
        TextView title=new TextView(this); title.setText(R.string.app_name); title.setTextSize(28); title.setTextColor(Color.rgb(15,90,84)); column.addView(title);
        text(column,"주제 글자와 약간의 여백을 드래그하세요. 화면 위치 제한 없이, 새 주제도 읽습니다.\n복사 시험판 · 작은 창의 복사 버튼으로 Hub 주제 입력칸에 붙여넣으세요. 자동 전달은 지원하지 않습니다.",17);
        CheckBox strict=new CheckBox(this);strict.setText(R.string.strict_topics);
        strict.setChecked(getSharedPreferences("ocr",0).getBoolean("strict_topics",false));
        strict.setOnCheckedChangeListener((button,checked)->getSharedPreferences("ocr",0).edit().putBoolean("strict_topics",checked).apply());column.addView(strict);
        state=text(column,"중지됨",18); state.setPadding(0,24,0,24);
        button(column,"1. 다른 앱 위에 표시 허용",v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
        button(column,"2. 화면 읽기 시작",v->startCapture());
        button(column,"3. WordStackHub 연결 코드 복사",v->{
            String token=getSharedPreferences("ocr",0).getString("token","");
            if(token.isEmpty()) { Toast.makeText(this,"화면 읽기를 먼저 시작하세요",Toast.LENGTH_LONG).show(); return; }
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("WordStack OCR 연결",BridgeCode.make(token)));
            Toast.makeText(this,"연결 코드 복사 완료 · 새 Hub 실행 후 실행기에 붙여넣어 실행하세요",Toast.LENGTH_LONG).show();
        });
        button(column,"화면 읽기 중지",v->stopService(new Intent(this,CaptureService.class)));
        text(column,"사용 순서\n① 위에 표시 허용 → 화면 읽기 시작\n② 전체 화면 공유를 허용하고 게임으로 이동\n③ 작은 창의 ‘영역’을 누른 뒤 주제 글자만 드래그\n④ 작은 창에 정확한 주제가 표시되는지 확인\n⑤ 새 WordStackHub 실행 → 연결 코드 실행 → 자동 입력 켜기\n\n화면을 회전하면 영역을 다시 지정하세요.\n영역은 랭킹·다른 사람 답안을 포함하지 않게 잡으세요.\n\n화면 이미지는 저장하거나 외부 서버에 보내지 않습니다. 인식 결과는 이 휴대폰의 로컬 연결로만 제공합니다. OCR은 잘못 읽을 수 있으므로 먼저 결과를 확인하세요.\n\n화면 공유는 시스템 표시 또는 앱의 중지 버튼으로 언제든 종료할 수 있습니다.",15);
        ScrollView scroll=new ScrollView(this); scroll.addView(column); setContentView(scroll);
        scroll.setOnApplyWindowInsetsListener((view,insets)->{
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);}
            else view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });scroll.requestApplyInsets();
    }
    TextView text(LinearLayout l,String s,int size) { TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(35,55,53));t.setPadding(0,12,0,12);l.addView(t);return t; }
    void button(LinearLayout l,String s,View.OnClickListener click) { Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(click);l.addView(b,new LinearLayout.LayoutParams(-1,-2)); }
    void startCapture() {
        if(CaptureService.running) { Toast.makeText(this,"이미 실행 중입니다. 게임에서 ‘영역’을 누르세요",Toast.LENGTH_LONG).show();return; }
        if(!Settings.canDrawOverlays(this)) { Toast.makeText(this,"먼저 다른 앱 위에 표시를 허용하세요",Toast.LENGTH_LONG).show();return; }
        if(Build.VERSION.SDK_INT>=33 && !notificationAsked && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){notificationAsked=true;requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},20);return;}
        beginCapture();
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){super.onRequestPermissionsResult(request,permissions,grants);if(request==20)beginCapture();}
    void beginCapture(){
        MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent request=Build.VERSION.SDK_INT>=34 ? manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay()) : manager.createScreenCaptureIntent();
        startActivityForResult(request,10);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==10 && result==RESULT_OK && data!=null) {
            Intent service=new Intent(this,CaptureService.class).putExtra("result",result).putExtra("data",data);
            startForegroundService(service);
            Toast.makeText(this,"게임으로 돌아가 작은 창의 ‘영역’을 누르세요",Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onResume(){super.onResume();handler.post(refresh);}
    @Override protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
}
