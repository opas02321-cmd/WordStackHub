package kr.wordtopic.ocr;
/** Requires consecutive readings; a changed or empty reading clears the accepted topic. */
final class TopicGate {
    private String previous="";
    private int count=0;
    synchronized String observe(String value) {
        if(value==null || value.isEmpty()){reset();return "";}
        if(value.equals(previous))count++;else{previous=value;count=1;}
        return count>=2 ? value : "";
    }
    synchronized void reset(){previous="";count=0;}
}
