package kr.wordtopic.ocr;
import android.os.SystemClock;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

final class LocalBridge implements AutoCloseable {
    private final String token;
    private volatile boolean active=true;
    private ServerSocket server;
    LocalBridge(String token) { this.token=token; }
    void start() throws IOException {
        server=new ServerSocket();server.setReuseAddress(true);
        server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),17653));
        Thread thread=new Thread(()->{
            while(active) {
                try(Socket socket=server.accept()) {
                    socket.setSoTimeout(1000);
                    BufferedReader reader=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8));
                    // Bound request line size; never read arbitrary HTTP bodies or files.
                    StringBuilder line=new StringBuilder(); int c;
                    while(line.length()<2048 && (c=reader.read())!=-1 && c!='\n') if(c!='\r') line.append((char)c);
                    String[] request=line.toString().split(" ");
                    boolean allowed=request.length==3 && request[0].equals("GET") && request[1].equals("/topic?token="+token);
                    JSONObject result=new JSONObject();
                    if(allowed) {
                        long age=SystemClock.elapsedRealtime()-CaptureService.updatedAt;
                        result.put("running",CaptureService.running && !CaptureService.paused);
                        result.put("topic",age<1800 ? CaptureService.topic : "");
                        result.put("ageMs",age);
                    } else result.put("error","forbidden");
                    byte[] bytes=result.toString().getBytes(StandardCharsets.UTF_8);
                    String header="HTTP/1.1 "+(allowed?"200 OK":"403 Forbidden")+"\r\nContent-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\nConnection: close\r\nContent-Length: "+bytes.length+"\r\n\r\n";
                    OutputStream output=socket.getOutputStream();output.write(header.getBytes(StandardCharsets.US_ASCII));output.write(bytes);output.flush();
                } catch(Exception e) { if(!active) break; }
            }
        },"local-topic-bridge");thread.setDaemon(true);thread.start();
    }
    @Override public void close() {active=false;try{if(server!=null)server.close();}catch(IOException ignored){} }
}
