package kr.wordtopic.ocr;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.UUID;

public class CaptureService extends Service {
    // This overlay uses a platform Activity/theme, not an AppCompat delegate.
    @android.annotation.SuppressLint("AppCompatCustomView")
    private static final class HandleText extends TextView {
        HandleText(Context context){super(context);}
        @Override public boolean performClick(){super.performClick();return true;}
    }
    static volatile boolean running=false,paused=false;
    static volatile String topic="",message="영역을 지정하세요";
    static volatile long updatedAt=0;
    private final Handler main=new Handler(Looper.getMainLooper());
    private HandlerThread workerThread; private Handler worker;
    private MediaProjection projection; private VirtualDisplay display; private ImageReader reader;
    private String recognitionHint="글자가 아직 보이지 않습니다";
    private TopicCatalog catalog;
    private TextRecognizer recognizer; private LocalBridge bridge;
    private WindowManager windows; private LinearLayout panel; private HandleText result; private View selector;
    private WindowManager.LayoutParams panelParams;
    private volatile Rect panelBounds;
    private volatile RectF region; private volatile boolean busy=false,ending=false,selecting=false;
    private int width,height,density; private long lastFrame=0;
    private final TopicGate gate=new TopicGate();
    private volatile int regionVersion=0;
    private final Runnable updatePanel=new Runnable(){public void run(){
        if(!running)return;
        updatePanelBounds();
        if(result!=null)result.setText((paused?"일시정지":topic.isEmpty()?message:"주제: "+topic));
        main.postDelayed(this,400);
    }};
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){super.onCreate();windows=(WindowManager)getSystemService(WINDOW_SERVICE);}
    @Override public int onStartCommand(Intent intent,int flags,int id){
        if(intent!=null && "STOP".equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(running || intent==null)return START_NOT_STICKY;
        try {
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("capture","화면 글자 읽기",NotificationManager.IMPORTANCE_LOW));
            PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
            Intent stopIntent=new Intent(this,CaptureService.class).setAction("STOP");
            // A notification action uses an explicit activity-free service intent.
            PendingIntent stop=PendingIntent.getService(this,1,stopIntent,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
            Notification note=new Notification.Builder(this,"capture").setSmallIcon(R.drawable.ic_ocr).setContentTitle("주제 읽기 실행 중").setContentText("지정 영역을 기기에서 읽습니다 · 중지 버튼으로 종료").setContentIntent(open).setOngoing(true).addAction(new Notification.Action.Builder(null,"중지",stop).build()).build();
            if(Build.VERSION.SDK_INT>=29)startForeground(1,note,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(1,note);
            Intent data=Build.VERSION.SDK_INT>=33?intent.getParcelableExtra("data",Intent.class):intent.getParcelableExtra("data");
            if(data==null){stopSelf();return START_NOT_STICKY;}
            workerThread=new HandlerThread("ocr-frames");workerThread.start();worker=new Handler(workerThread.getLooper());
            catalog=new TopicCatalog();
            try(java.io.InputStream stream=getAssets().open("topics.json")){
                org.json.JSONArray values=new org.json.JSONArray(readAsset(stream));
                for(int i=0;i<values.length();i++)catalog.add(values.getString(i));
            }
            recognizer=TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
            projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(intent.getIntExtra("result",Activity.RESULT_CANCELED),data);
            if(projection==null)throw new IllegalStateException("화면 공유 승인이 필요합니다");
            projection.registerCallback(new MediaProjection.Callback(){
                @Override public void onStop(){main.post(()->stopSelf());}
                @Override public void onCapturedContentResize(int w,int h){main.post(()->resize(w,h));}
            },main);
            DisplayMetrics metrics=new DisplayMetrics();windows.getDefaultDisplay().getRealMetrics(metrics);
            width=metrics.widthPixels;height=metrics.heightPixels;density=metrics.densityDpi;
            reader=createReader(width,height);
            display=projection.createVirtualDisplay("WordTopicOCR",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,main);
            String token=getSharedPreferences("ocr",0).getString("token","");
            if(token.isEmpty()){token=UUID.randomUUID().toString().replace("-","");getSharedPreferences("ocr",0).edit().putString("token",token).apply();}
            bridge=new LocalBridge(token);bridge.start();
            running=true;paused=false;clearTopic();message="게임에서 ‘영역’을 누르세요";
            showPanel();main.post(updatePanel);
        } catch(Exception e){message="시작 실패: "+(e instanceof java.net.BindException?"이전 OCR 앱을 종료한 뒤 시작하세요":e.getClass().getSimpleName());Toast.makeText(this,message,Toast.LENGTH_LONG).show();stopSelf();}
        return START_NOT_STICKY;
    }
    private ImageReader createReader(int w,int h){
        ImageReader r=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,3);
        r.setOnImageAvailableListener(this::frame,worker);return r;
    }
    private void resize(int w,int h){
        if(ending || display==null || w<=0 || h<=0 || (w==width && h==height))return;
        region=null;clearTopic();message="화면 변경됨 · 영역을 다시 지정하세요";
        removeSelector();ImageReader old=reader;
        width=w;height=h;reader=createReader(w,h);
        display.resize(w,h,density);display.setSurface(reader.getSurface());
        if(old!=null)old.close();
        if(panel!=null && panelParams!=null){panelParams.y=Math.max(dp(50),height-dp(110));windows.updateViewLayout(panel,panelParams);updatePanelBounds();}
    }
    @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);
        if(Build.VERSION.SDK_INT<34){DisplayMetrics d=new DisplayMetrics();windows.getDefaultDisplay().getRealMetrics(d);resize(d.widthPixels,d.heightPixels);}
    }
    private void frame(ImageReader source){
        Image image=null;Bitmap crop=null;
        try {
            image=source.acquireLatestImage();if(image==null)return;
            final int capturedVersion=regionVersion;
            RectF area=region;
            long now=SystemClock.elapsedRealtime();
            if(!running || ending || paused || selecting || area==null || busy || now-lastFrame<650)return;
            Rect floating=panelBounds;
            if(floating!=null && Rect.intersects(floating,new Rect(Math.round(area.left*width),Math.round(area.top*height),Math.round(area.right*width),Math.round(area.bottom*height)))){
                clearTopic();message="표시창이 주제를 가립니다 · 창을 아래로 이동";return;
            }
            busy=true;lastFrame=now;
            int w=image.getWidth(),h=image.getHeight();
            Image.Plane plane=image.getPlanes()[0];int pixel=plane.getPixelStride(),row=plane.getRowStride();
            if(pixel!=4)throw new IllegalStateException("RGBA 픽셀 형식이 아닙니다");
            ByteBuffer buffer=plane.getBuffer();
            int left=Math.max(0,Math.min(w-1,Math.round(area.left*w))),top=Math.max(0,Math.min(h-1,Math.round(area.top*h)));
            int right=Math.max(left+1,Math.min(w,Math.round(area.right*w))),bottom=Math.max(top+1,Math.min(h,Math.round(area.bottom*h)));
            int cw=right-left,ch=bottom-top;
            // Copy only the selected rectangle; the last source row need not include padding.
            ByteBuffer tight=ByteBuffer.allocateDirect(cw*ch*4);
            byte[] rowBytes=new byte[cw*4];
            for(int y=top;y<bottom;y++){
                buffer.position(y*row+left*4);buffer.get(rowBytes);tight.put(rowBytes);
            }
            tight.rewind();Bitmap part=Bitmap.createBitmap(cw,ch,Bitmap.Config.ARGB_8888);part.copyPixelsFromBuffer(tight);
            float scale=Math.min(2f,1600f/part.getWidth());
            crop=Bitmap.createScaledBitmap(part,Math.max(1,Math.round(part.getWidth()*scale)),Math.max(1,Math.round(part.getHeight()*scale)),true);
            if(crop!=part)part.recycle();
            Bitmap framed=Bitmap.createBitmap(crop.getWidth()+32,crop.getHeight()+32,Bitmap.Config.ARGB_8888);
            Canvas border=new Canvas(framed);border.drawColor(crop.getPixel(0,0));border.drawBitmap(crop,16,16,null);
            crop.recycle();crop=framed;
            final Bitmap used=crop;crop=null;
            recognizer.process(InputImage.fromBitmap(used,0))
                .addOnSuccessListener(text->{if(running && !paused && !selecting && capturedVersion==regionVersion)acceptText(bestLine(text));})
                .addOnFailureListener(error->{if(capturedVersion==regionVersion){clearTopic();message="글자 인식 실패 · 영역을 다시 지정하세요";}})
                .addOnCompleteListener(task->{used.recycle();busy=false;if(ending && recognizer!=null)recognizer.close();});
        } catch(Exception e){busy=false;clearTopic();message="화면 처리 대기 · 영역을 다시 지정하세요";if(crop!=null)crop.recycle();}
        finally {if(image!=null)image.close();}
    }
    private String bestLine(Text text){
        boolean strict=getSharedPreferences("ocr",0).getBoolean("strict_topics",false);
        String bestKnown="",bestOther="";int knownScore=0,otherScore=0,lines=0;boolean ambiguous=false;
        for(Text.TextBlock block:text.getTextBlocks())for(Text.Line line:block.getLines()){
            String raw=line.getText().trim();Rect box=line.getBoundingBox();
            if(!raw.isEmpty())lines++;
            if(box==null)continue;
            String known=catalog.match(raw);
            int weight=box.height()*10000+box.width();
            if(!known.isEmpty() && weight>knownScore){knownScore=weight;bestKnown=known;}
            String other=TopicCatalog.readableTitle(raw);
            if(!other.isEmpty()){
                if(weight>otherScore*1.2){otherScore=weight;bestOther=other;ambiguous=false;}
                else if(weight>=otherScore*0.8 && !TopicCatalog.key(other).equals(TopicCatalog.key(bestOther)))ambiguous=true;
            }
        }
        if(!bestKnown.isEmpty()){recognitionHint="인식 중";return bestKnown;}
        if(!strict && !bestOther.isEmpty() && !ambiguous){recognitionHint="선택 영역의 글자 읽기";return bestOther;}
        if(lines==0)recognitionHint="글자 미검출 · 글자 주변 여백도 조금 포함해 주세요";
        else if(strict && !bestOther.isEmpty())recognitionHint="목록에 없는 주제 · 앱에서 ‘등록된 주제만’ 옵션을 끄세요";
        else if(ambiguous)recognitionHint="비슷한 크기의 글자가 여러 줄입니다 · 제목 한 줄만 선택해 주세요";
        else recognitionHint="제목으로 읽을 글자 대기 · 알림이나 키패드가 가리는지 확인하세요";
        return "";
    }
    private void acceptText(String value){
        topic=gate.observe(value);
        TopicDraft.remember(topic);
        updatedAt=SystemClock.elapsedRealtime();
        if(value.isEmpty())message=recognitionHint;
        else if(!topic.isEmpty())message="인식 중";
        else message="주제 확인 중: "+value;
    }
    private void clearTopic(){regionVersion++;topic="";gate.reset();updatedAt=SystemClock.elapsedRealtime();}
    private void showPanel(){
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(12,8,12,8);panel.setBackgroundColor(0xEE123B37);
        result=new HandleText(this);result.setTextSize(14);result.setTextColor(Color.WHITE);result.setMaxLines(2);panel.addView(result,new LinearLayout.LayoutParams(dp(280),-2));
        result.setText(R.string.overlay_handle);
        LinearLayout row=new LinearLayout(this);panel.addView(row);
        smallButton(row,"영역",v->selectRegion());
        smallButton(row,"일시정지",v->{paused=!paused;clearTopic();message=paused?"일시정지":"인식 중";((Button)v).setText(paused?"재개":"일시정지");});
        smallButton(row,"복사",v->{
            String value=topic;
            if(value==null || value.isEmpty() || SystemClock.elapsedRealtime()-updatedAt>=1800){
                Toast.makeText(this,"먼저 주제를 인식하세요",Toast.LENGTH_SHORT).show();return;
            }
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("주제",value));
            Toast.makeText(this,"주제 복사 완료 · Hub의 주제 직접 입력에 붙여넣으세요",Toast.LENGTH_LONG).show();
        });
        smallButton(row,"종료",v->stopSelf());
        panelParams=params(-2,-2);panelParams.x=12;panelParams.y=Math.max(dp(50),height-dp(110));
        windows.addView(panel,panelParams);panel.post(this::updatePanelBounds);
        result.setOnTouchListener(new View.OnTouchListener(){float x,y;int startX,startY;
            public boolean onTouch(View v,android.view.MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();startX=panelParams.x;startY=panelParams.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){panelParams.x=Math.max(0,startX+(int)(e.getRawX()-x));panelParams.y=Math.max(0,startY+(int)(e.getRawY()-y));windows.updateViewLayout(panel,panelParams);updatePanelBounds();return true;}if(e.getAction()==MotionEvent.ACTION_UP)v.performClick();return true;
            }});
    }
    private void updatePanelBounds(){
        if(panel==null || panel.getVisibility()!=View.VISIBLE || panel.getWidth()==0){panelBounds=null;return;}
        int[] location=new int[2];panel.getLocationOnScreen(location);
        panelBounds=new Rect(location[0],location[1],location[0]+panel.getWidth(),location[1]+panel.getHeight());
    }
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private void smallButton(LinearLayout row,String label,View.OnClickListener onClick){Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(8,0,8,0);b.setOnClickListener(onClick);row.addView(b,new LinearLayout.LayoutParams(-2,dp(44)));}
    private WindowManager.LayoutParams params(int w,int h){
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.START;
        if(Build.VERSION.SDK_INT>=30)p.setFitInsetsTypes(0);
        if(Build.VERSION.SDK_INT>=28)p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        return p;
    }
    private static String readAsset(java.io.InputStream stream)throws java.io.IOException{
        java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[4096];int count;
        while((count=stream.read(buffer))!=-1)out.write(buffer,0,count);
        return out.toString("UTF-8");
    }
    private void selectRegion(){
        if(selecting)return;clearTopic();selecting=true;panel.setVisibility(View.GONE);
        selector=new View(this){float x1,y1,x2,y2;boolean down=false;Paint paint=new Paint(3);
            @Override protected void onDraw(Canvas canvas){
                canvas.drawColor(0x55333333);paint.setColor(Color.WHITE);paint.setTextSize(34);canvas.drawText("주제 글자와 여백을 드래그 · 위치 제한 없음",24,60,paint);
                if(down){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4);paint.setColor(0xFF2DD4BF);canvas.drawRect(Math.min(x1,x2),Math.min(y1,y2),Math.max(x1,x2),Math.max(y1,y2),paint);paint.setStyle(Paint.Style.FILL);}
            }
            @Override public boolean performClick(){super.performClick();return true;}
            @Override public boolean onTouchEvent(MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){x1=x2=e.getX();y1=y2=e.getY();down=true;invalidate();return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){x2=e.getX();y2=e.getY();invalidate();return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){performClick();x2=e.getX();y2=e.getY();
                    if(Math.abs(x2-x1)>=12 && Math.abs(y2-y1)>=10){
                        int[] loc=new int[2];getLocationOnScreen(loc);
                        RectF candidate=new RectF(Math.max(0,(Math.min(x1,x2)+loc[0])/width),Math.max(0,(Math.min(y1,y2)+loc[1])/height),Math.min(1,(Math.max(x1,x2)+loc[0])/width),Math.min(1,(Math.max(y1,y2)+loc[1])/height));
                        if(TopicCatalog.validRegion(candidate.top,candidate.bottom)){
                            region=candidate;message="영역 선택 완료 · 글자를 읽고 있습니다";
                        }else{region=null;message="영역 좌표를 확인할 수 없습니다 · 다시 드래그해 주세요";}

                    } else {region=null;message="선택 영역이 너무 작습니다 · 글자와 여백을 함께 선택하세요";}
                    removeSelector();return true;
                }return true;
            }
            @Override public boolean dispatchKeyEvent(KeyEvent e){if(e.getKeyCode()==KeyEvent.KEYCODE_BACK){if(e.getAction()==KeyEvent.ACTION_UP)removeSelector();return true;}return super.dispatchKeyEvent(e);}
        };
        WindowManager.LayoutParams p=params(-1,-1);p.flags&=~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        windows.addView(selector,p);selector.setFocusableInTouchMode(true);selector.requestFocus();
    }
    private void removeSelector(){if(selector!=null){try{windows.removeView(selector);}catch(Exception ignored){}selector=null;}selecting=false;if(panel!=null)panel.setVisibility(View.VISIBLE);}
    @Override public void onDestroy(){
        ending=true;running=false;paused=false;clearTopic();if(!message.startsWith("시작 실패"))message="화면 읽기가 종료되었습니다";main.removeCallbacksAndMessages(null);
        if(bridge!=null)bridge.close();removeSelector();if(panel!=null){try{windows.removeView(panel);}catch(Exception ignored){}panel=null;}
        if(display!=null){display.release();display=null;}if(reader!=null){reader.close();reader=null;}
        if(projection!=null){projection.stop();projection=null;}
        if(recognizer!=null && !busy)recognizer.close();if(workerThread!=null)workerThread.quitSafely();
        stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();
    }
}
