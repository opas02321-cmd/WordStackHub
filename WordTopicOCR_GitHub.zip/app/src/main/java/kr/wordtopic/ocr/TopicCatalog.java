package kr.wordtopic.ocr;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
final class TopicCatalog {
    private final Map<String,String> names=new HashMap<>();
    static String key(String value){
        StringBuilder result=new StringBuilder();
        for(int i=0;i<value.length();i++){
            char c=value.charAt(i);if(Character.isLetterOrDigit(c))result.append(c);
        }
        return result.toString().toLowerCase(Locale.ROOT);
    }
    void add(String value){names.putIfAbsent(key(value),value);}
    String match(String value){return value==null ? "" : names.getOrDefault(key(value),"");}
    static String readableTitle(String value){
        if(value==null)return "";
        value=value.trim();String compact=key(value);
        if(compact.length()<2 || compact.length()>40)return "";
        for(String noise:new String[]{"클릭하여","입력하세요","화면공유","키보드","입력창","연결코드","주제판","알림","텍스트모바일","자동입력","일시정지"})
            if(compact.contains(noise))return "";
        int hangul=0;
        for(int i=0;i<compact.length();i++)if(compact.charAt(i)>='가' && compact.charAt(i)<='힣')hangul++;
        return hangul>=2 ? value : "";
    }
    static boolean validRegion(float top,float bottom){return Float.isFinite(top) && Float.isFinite(bottom) && top>=0 && bottom<=1 && bottom>top;}
}
