package kr.wordtopic.ocr;

import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Only sends text when the user taps a button; never reads editor contents. */
public class TopicKeyboardService extends InputMethodService {
    private TextView state;
    private Button sendTopic;
    private Button replaceTopic;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable(){ public void run(){
        if(sendTopic!=null){
            String value=TopicDraft.fresh();
            sendTopic.setEnabled(!value.isEmpty());
            sendTopic.setText(value.isEmpty()?"인식한 주제 없음 · 게임에서 영역 선택":"최근 OCR 주제 입력: "+value);
            if(replaceTopic!=null){
                replaceTopic.setEnabled(!value.isEmpty());
                replaceTopic.setText(value.isEmpty()?"교체할 OCR 주제 없음":"주제 바로 교체하고 닫기: "+value);
            }
        }
        handler.postDelayed(this,500);
    }};
    @Override public boolean onEvaluateFullscreenMode(){return false;}
    @Override public View onCreateInputView(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(16,8,16,8);box.setBackgroundColor(Color.rgb(235,245,242));
        state=new TextView(this);state.setText("Hub의 주제 입력칸에서 테스트하세요 · 자동 입력은 꺼두세요");
        state.setTextSize(15);state.setTextColor(Color.BLACK);box.addView(state);
        button(box,"① 테스트: 도시 입력",v->commit("도시"));
        sendTopic=button(box,"② 최근 OCR 주제 입력",v->{
            String value=TopicDraft.fresh();
            if(value.isEmpty()){state.setText("최근 30초 이내에 읽은 주제가 없습니다");return;}
            commit(value);
        });
        replaceTopic=button(box,"주제 바로 교체하고 닫기",v->{
            // Commit exactly the topic shown to the user, even if OCR updates during the tap.
            String shown=replaceTopic.getText().toString();
            String prefix="주제 바로 교체하고 닫기: ";
            String current=TopicDraft.fresh();
            if(!shown.startsWith(prefix) || current.isEmpty()){
                state.setText("인식한 주제가 없습니다 · 게임에서 주제를 다시 읽으세요");return;
            }
            String value=shown.substring(prefix.length());
            if(!value.equals(current)){
                state.setText("OCR 주제가 바뀌었습니다 · 버튼의 새 주제를 확인하고 다시 누르세요");return;
            }
            InputConnection connection=getCurrentInputConnection();
            if(connection==null){state.setText("Hub 주제 입력칸을 먼저 선택하세요");return;}
            connection.beginBatchEdit();
            boolean accepted=false;
            try {
                connection.finishComposingText();
                if(!connection.performContextMenuAction(android.R.id.selectAll)){
                    state.setText("전체 선택 실패 · 교체하지 않았습니다");return;
                }
                accepted=connection.commitText(value,1);
            } finally {connection.endBatchEdit();}
            if(!accepted){state.setText("교체 요청 실패 · 입력칸을 확인하세요");return;}
            state.setText("주제 교체 요청: "+value);
            requestHideSelf(0);
        });
        LinearLayout deleteRow=new LinearLayout(this);box.addView(deleteRow);
        Button back=new Button(this);back.setText("⌫ 한 글자 지우기");
        deleteRow.addView(back,new LinearLayout.LayoutParams(0,-2,1));
        back.setOnClickListener(v->{
            if(getCurrentInputConnection()==null){state.setText("입력칸을 먼저 선택하세요");return;}
            sendDownUpKeyEvents(android.view.KeyEvent.KEYCODE_DEL);
            state.setText("삭제 키 보냄 · 입력칸을 확인하세요");
        });
        Button clear=new Button(this);clear.setText("입력칸 전체 지우기");
        deleteRow.addView(clear,new LinearLayout.LayoutParams(0,-2,1));
        clear.setOnClickListener(v->{
            InputConnection connection=getCurrentInputConnection();
            if(connection==null){state.setText("입력칸을 먼저 선택하세요");return;}
            connection.finishComposingText();
            if(!connection.performContextMenuAction(android.R.id.selectAll)){
                state.setText("전체 선택 요청 실패 · 한 글자 지우기를 사용하세요");return;
            }
            boolean accepted=connection.commitText("",1);
            state.setText(accepted?"전체 삭제 요청 보냄 · 입력칸을 확인하세요":"삭제 요청 실패 · 입력칸을 다시 선택하세요");
        });
        button(box,"③ 입력 완료 · 키보드 닫기",v->requestHideSelf(0));
        button(box,"다른 키보드로 변경",v->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
        return box;
    }
    private Button button(LinearLayout parent,String title,View.OnClickListener action){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setOnClickListener(action);
        parent.addView(b,new LinearLayout.LayoutParams(-1,-2));return b;
    }
    private void commit(String value){
        InputConnection connection=getCurrentInputConnection();
        if(connection==null){state.setText("입력 연결 없음 · Hub 입력칸을 다시 누르세요");return;}
        boolean accepted=connection.commitText(value,1);
        state.setText(accepted?"입력 요청 보냄 · 입력칸에 ‘"+value+"’가 보이는지 확인하세요":"입력 요청 실패 · 입력칸을 다시 누르세요");
    }
    @Override public void onStartInputView(EditorInfo info,boolean restarting){
        super.onStartInputView(info,restarting);handler.removeCallbacks(refresh);handler.post(refresh);
    }
    @Override public void onFinishInputView(boolean finishing){handler.removeCallbacks(refresh);super.onFinishInputView(finishing);}
    @Override public void onDestroy(){handler.removeCallbacks(refresh);super.onDestroy();}
}
