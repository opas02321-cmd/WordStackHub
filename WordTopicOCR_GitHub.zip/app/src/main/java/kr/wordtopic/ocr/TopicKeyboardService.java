package kr.wordtopic.ocr;

import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Only sends text when the user taps a button; never reads editor contents. */
public class TopicKeyboardService extends InputMethodService {
    private TextView state;
    private Button sendTopic;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable(){ public void run(){
        if(sendTopic!=null){
            String value=TopicDraft.fresh();
            sendTopic.setEnabled(!value.isEmpty());
            sendTopic.setText(value.isEmpty()?"인식한 주제 없음 · 게임에서 영역 선택":"최근 OCR 주제 입력: "+value);
        }
        handler.postDelayed(this,500);
    }};
    @Override public boolean onEvaluateFullscreenMode(){return false;}
    @Override public View onCreateInputView(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(16,8,16,8);box.setBackgroundColor(Color.rgb(235,245,242));
        state=new TextView(this);state.setText("Hub의 주제 입력칸에서 테스트하세요 · 자동 입력은 꺼두세요");
        state.setTextSize(15);state.setTextColor(Color.BLACK);box.addView(state);
        button(box,"① 테스트: 도시 입력",v->commit("도시"));
        sendTopic=button(box,"② 최근 OCR 주제 입력",v->{
            String value=TopicDraft.fresh();
            if(value.isEmpty()){state.setText("최근 30초 이내에 읽은 주제가 없습니다");return;}
            commit(value);
        });
        button(box,"③ 입력 완료 · 키보드 닫기",v->requestHideSelf(0));
        button(box,"다른 키보드로 변경",v->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
        return box;
    }
    private Button button(LinearLayout parent,String title,View.OnClickListener action){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setOnClickListener(action);
        parent.addView(b,new LinearLayout.LayoutParams(-1,-2));return b;
    }
    private void commit(String value){
        InputConnection connection=getCurrentInputConnection();
        if(connection==null){state.setText("입력 연결 없음 · Hub 입력칸을 다시 누르세요");return;}
        boolean accepted=connection.commitText(value,1);
        state.setText(accepted?"입력 요청 보냄 · 입력칸에 ‘"+value+"’가 보이는지 확인하세요":"입력 요청 실패 · 입력칸을 다시 누르세요");
    }
    @Override public void onStartInputView(EditorInfo info,boolean restarting){
        super.onStartInputView(info,restarting);handler.removeCallbacks(refresh);handler.post(refresh);
    }
    @Override public void onFinishInputView(boolean finishing){handler.removeCallbacks(refresh);super.onFinishInputView(finishing);}
    @Override public void onDestroy(){handler.removeCallbacks(refresh);super.onDestroy();}
}
