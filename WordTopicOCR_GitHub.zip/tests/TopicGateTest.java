package kr.wordtopic.ocr;
public class TopicGateTest {
    static void expect(String actual,String expected){if(!actual.equals(expected))throw new AssertionError(actual+" != "+expected);}
    public static void main(String[] args){
        TopicGate gate=new TopicGate();
        expect(gate.observe("초밥"),"");expect(gate.observe("초밥"),"초밥");
        expect(gate.observe("국내 섬"),"");expect(gate.observe("국내 섬"),"국내 섬");
        expect(gate.observe(""),"");expect(gate.observe("국내 섬"),"");
        gate.reset();expect(gate.observe("초밥"),"");expect(gate.observe(null),"");
        expect(gate.observe("초밥"),"");expect(gate.observe("초밥"),"초밥");
        System.out.println("TopicGate: 11 assertions passed");
    }
}
