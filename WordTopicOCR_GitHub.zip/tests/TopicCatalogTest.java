package kr.wordtopic.ocr;
public class TopicCatalogTest {
    static void check(boolean result){if(!result)throw new AssertionError();}
    public static void main(String[] args){
        TopicCatalog catalog=new TopicCatalog();catalog.add("국내 섬");catalog.add("초밥");
        check(catalog.match("국내섬").equals("국내 섬"));
        check(catalog.match("처음보는주제").isEmpty());
        check(TopicCatalog.readableTitle("처음 보는 주제").equals("처음 보는 주제"));
        check(TopicCatalog.readableTitle("한국을 빛낸 100명의 위인들").length()>0);
        check(TopicCatalog.readableTitle("입력창을 클릭하여 입력하세요").isEmpty());
        check(TopicCatalog.readableTitle("알림 텍스트 모바일").isEmpty());
        check(TopicCatalog.readableTitle("ㅊ ㅂ ㅇ").isEmpty());
        check(TopicCatalog.readableTitle("qwertyuiop").isEmpty());
        check(TopicCatalog.validRegion(0.18f,0.34f));
        check(TopicCatalog.validRegion(0.60f,0.90f));
        check(TopicCatalog.validRegion(0f,0.35f));
        check(TopicCatalog.validRegion(0.10f,0.50f));
        check(!TopicCatalog.validRegion(0.6f,0.3f));
        check(!TopicCatalog.validRegion(Float.NaN,0.3f));
        check(!TopicCatalog.validRegion(0.1f,1.1f));
        System.out.println("TopicCatalog 0.3: 15 region/unknown-title/noise regressions PASS");
    }
}
